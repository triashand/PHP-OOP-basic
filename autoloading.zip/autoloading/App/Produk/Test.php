<?php

class Test {
    public function __construct() 
    {
        echo "ini adalah kelas " . __CLASS__ ;
    }
}