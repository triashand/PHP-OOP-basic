<?php

// require 'App/Produk/InfoProduk.php';
// require 'App/Produk/Produk.php';
// require 'App/Produk/Komik.php';
// require 'App/Produk/Game.php';
// require 'App/Produk/CetakInfoProduk.php';

// atau bisa gunakan library / fungsi untuk autoloading
// agar tidak manual
// spl_autoload_register()

// closure
spl_autoload_register( function( $class ) {
    //require_once 'Produk/' . $class . '.php';
    require_once __DIR__ . '/Produk/' . $class . '.php';
});