<?php
//require semua class yang ada agar dapat berjalan

// require 'App/Produk/InfoProduk.php';
// require 'App/Produk/Produk.php';
// require 'App/Produk/Komik.php';
// require 'App/Produk/Game.php';
// require 'App/Produk/CetakInfoProduk.php';

// cara diatas akan jadi masalah jika file semakin banyak
// include satu persatu
// pindah semua file diatas kedalam file terpisah
// misal disimpan didalam folder App dengan file init.php

require 'App/init.php';


$produk1 = new Komik("Naruto", "Masashi K", "Shonen Jump", 200000, 100);
$produk2 = new Game("Uncharted", "Neil D", "Sony Comp", 300000,200);

$cetakProduk = new CetakInfoProduk();
$cetakProduk->tambahProduk( $produk1 );
$cetakProduk->tambahProduk( $produk2 );

echo $cetakProduk->cetak();

echo "<hr>";

new Test();