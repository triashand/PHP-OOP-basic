<?php

// require 'App/Produk/InfoProduk.php';
// require 'App/Produk/Produk.php';
// require 'App/Produk/Komik.php';
// require 'App/Produk/Game.php';
// require 'App/Produk/CetakInfoProduk.php';
// require 'App/Produk/User.php';

// require 'App/Service/User.php';

// atau bisa gunakan library / fungsi untuk autoloading
// agar tidak manual
// spl_autoload_register()

// closure
// spl_autoload_register( function( $class ) {
//     //require_once 'Produk/' . $class . '.php';
//     require_once __DIR__ . '/Produk/' . $class . '.php';
//     //tidak bisa melakukan seperti dibawah
//     //require_once __DIR__ . '/Service/' . $class . '.php';
// });

spl_autoload_register( function( $class ) {
    $class = explode('\\', $class);
    $class = end($class);
    require_once __DIR__ . '/Produk/' . $class . '.php';
});

spl_autoload_register( function( $class ) {
    $class = explode('\\', $class);
    $class = end($class);
    require_once __DIR__ . '/Service/' . $class . '.php';
});